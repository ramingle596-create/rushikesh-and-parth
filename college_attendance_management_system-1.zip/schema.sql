CREATE DATABASE IF NOT EXISTS college_attendance
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
